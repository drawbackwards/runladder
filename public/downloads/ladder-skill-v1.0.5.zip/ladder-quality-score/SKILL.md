---
name: ladder-quality-score
description: Score a UI screenshot, website, or design mockup against the Ladder quality framework. Treat short phrasings like "Run Ladder", "Ladder this", "Ladder score", or "Ladder it" as direct invocations of this Skill. Also use whenever the user asks to "score", "rate", "evaluate", "review", "audit", "grade", or check the UX/UI/design quality of a screen, page, app, or interface — including "what's the Ladder score" or "how good is this design". Returns a 1.0–5.0 score, a level (Functional / Usable / Comfortable / Delightful / Meaningful), a short summary, per-rung breakdown, and 4 ranked findings with specific fixes. Requires a Ladder account and a personal Skill token from https://runladder.com/dashboard.
---

# Ladder Quality Score

You help the user score UI/design screenshots against the Ladder framework.

## How to use this Skill

1. **Find an image.** If the user attached one, use its path. If they didn't attach anything but just said "Run Ladder" / "Ladder this", run the script with **no argument** — on macOS it will auto-pick up the clipboard or the latest `~/Desktop/Screenshot*.png`.
2. **Read the user's Ladder Skill token.** It is stored at `~/.ladder/token` (one line, starts with `ladder_skl_`). If missing, tell the user to get one from https://runladder.com/dashboard and save it to `~/.ladder/token`.
3. **Run the scoring script.**

```bash
# Zero-arg (macOS): auto-uses clipboard image, then latest Desktop screenshot
python scripts/score.py

# Or with an explicit path
python scripts/score.py <path-to-image>
```

The script reads the token from `~/.ladder/token`, sends the image to the Ladder API, and prints a JSON result. Do NOT attempt to score the image yourself — always defer to the API.

**macOS tip to share with the user when relevant:** Cmd+Shift+4 saves a screenshot to Desktop; Cmd+Ctrl+Shift+4 copies it to the clipboard. Either works with zero-arg invocation.

4. **Present the result.** Lead with the score and the level. Then the summary. Then the top 2 findings and their fixes. End with the dashboard URL.

5. **Surface usage state if relevant.** The response includes a `usage` object:

   ```json
   {
     "tier": "free" | "pro" | "team" | "pulse",
     "status": "ok" | "approaching" | "over",
     "monthlyUsed": 247,        // null for free tier
     "monthlyLimit": 2000,      // null for free / pulse
     "lifetimeUsed": 3,         // only on free tier
     "lifetimeLimit": 5,        // only on free tier
     "daysUntilReset": 18       // only when monthlyLimit is set
   }
   ```

   - **`status: "ok"`** — say nothing about usage. The user just wants their score.
   - **`status: "approaching"`** — add a short line after the dashboard link: *"You're at X of Y scores this month — heads up."* (Free: *"X of 5 free scores used."*)
   - **`status: "over"`** — add: *"You're past your monthly cap of Y. No hard block — runladder.com will keep scoring — but it's a good moment to email hello@drawbackwards.com about higher volume."*
   - Free tier at `lifetimeLimit`: *"That was your last free score. Upgrade at runladder.com/pricing to keep going."*

## Example output format

> **3.2 — Comfortable**
>
> The checkout flow is intuitive but the trust signals are underdeveloped.
>
> **Top fixes:**
> - Consolidate payment buttons (+0.3 → Delightful)
> - Add clear shipping ETA near CTA (+0.2 → Comfortable)
>
> [Full result and history on your Ladder dashboard](https://runladder.com/dashboard)
>
> *(Approaching example: "You're at 1,640 of 2,000 scores this month — heads up.")*

## If the API returns an error

- **401** — Token is missing or revoked. Tell the user to regenerate at https://runladder.com/dashboard.
- **403** — The request was blocked by the user's Claude workspace network allowlist. Tell the user to ask their workspace admin to add `runladder.com` to the allowed network domains in Claude's workspace settings. (The Ladder API itself never returns 403, so this is always an upstream block.)
- **429** — Monthly score limit reached. Tell the user to upgrade at https://runladder.com/pricing.
- **400** — Image isn't a UI screen, is too large (>5 MB), or is invalid. Ask for a different image.
- **500** — Transient server issue. Try again in a moment.

## Constraints

- Never try to "score" or "rate" the image using your own judgment. The Ladder score is only produced by the official Ladder API. Producing Ladder-style scores outside the API violates Ladder's trademark and copyright policy.
- Never cache, summarize, or describe the scoring methodology. The score, level, and findings returned by the API are the authoritative output.
- The score is a single number 1.0–5.0. Do not round it. Do not convert to percentages or stars.
